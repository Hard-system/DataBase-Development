-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: mysql.abdn.ac.uk:3306
-- Generation Time: Nov 13, 2017 at 04:52 PM
-- Server version: 5.5.21-log
-- PHP Version: 5.6.30

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `t01kkk16_museum`
--
CREATE DATABASE `t01kkk16_museum` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `t01kkk16_museum`;

-- --------------------------------------------------------

--
-- Stand-in structure for view `Art_object`
--
CREATE TABLE IF NOT EXISTS `Art_object` (
`YearOfCreation` datetime
,`Title` varchar(45)
,`Description` varchar(45)
,`Culture` varchar(45)
,`Epoch` varchar(45)
,`Style` varchar(45)
,`Artist_ArtistName` varchar(45)
,`DateOfAcquiry` datetime
,`Status` varchar(45)
,`Cost` int(11)
,`ArtObject_ArtObjNo` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `Count_objects_from_artist`
--
CREATE TABLE IF NOT EXISTS `Count_objects_from_artist` (
`Count_of_Objects` bigint(21)
,`Artist_name` varchar(45)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `Select_from_borrowed_a`
--
CREATE TABLE IF NOT EXISTS `Select_from_borrowed_a` (
`DateBorrowed` datetime
,`DateOfReturn` datetime
,`YearOfCreation` datetime
,`Title` varchar(45)
,`Culture` varchar(45)
,`Epoch` varchar(45)
,`Style` varchar(45)
,`Artist_ArtistName` varchar(45)
,`memberName` varchar(45)
);
-- --------------------------------------------------------

--
-- Table structure for table `artist`
--

CREATE TABLE IF NOT EXISTS `artist` (
  `ArtistName` varchar(45) NOT NULL,
  `DateOfBirth` datetime NOT NULL,
  `DateOfDeath` datetime NOT NULL,
  `countryOfOrigin` varchar(45) DEFAULT NULL,
  `epoch` varchar(45) DEFAULT NULL,
  `mainstyle` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ArtistName`,`DateOfBirth`,`DateOfDeath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artist`
--

INSERT INTO `artist` (`ArtistName`, `DateOfBirth`, `DateOfDeath`, `countryOfOrigin`, `epoch`, `mainstyle`, `description`) VALUES
('Ivan Ivanov', '1933-12-01 00:00:00', '2017-01-10 00:00:00', 'Russian', 'Modern', 'Abstract', 'Painter'),
('John', '1943-06-03 00:00:00', '2001-01-04 00:00:00', 'Canada', 'renaissance', 'Abstract', 'painter'),
('Leonardo Davinci', '1954-12-01 00:00:00', '2014-01-10 00:00:00', 'Italy', 'Renaissance', 'Abstract', 'painting Artist'),
('Michelangelo', '1921-02-05 00:00:00', '1994-03-04 00:00:00', 'Italy', 'renaissance', 'Romance', 'painter'),
('Peter', '1900-03-04 00:00:00', '2000-01-04 00:00:00', 'USA', 'modern', 'Romance', 'Sculptor'),
('Sin Zing', '1889-09-04 00:00:00', '1934-09-06 00:00:00', 'China', 'Modern', 'Psycho Installations', 'Not famous artist');

-- --------------------------------------------------------

--
-- Table structure for table `artobject`
--

CREATE TABLE IF NOT EXISTS `artobject` (
  `ArtObjNo` int(11) NOT NULL AUTO_INCREMENT,
  `YearOfCreation` datetime DEFAULT NULL,
  `Title` varchar(45) DEFAULT NULL,
  `Description` varchar(45) DEFAULT NULL,
  `Culture` varchar(45) DEFAULT NULL,
  `Epoch` varchar(45) DEFAULT NULL,
  `Style` varchar(45) DEFAULT NULL,
  `exhibitionID` int(11) DEFAULT NULL,
  `Artist_ArtistName` varchar(45) NOT NULL,
  `Artist_DateOfBirth` datetime NOT NULL,
  `Artist_DateOfDeath` datetime NOT NULL,
  `Museum_museumID` int(11) NOT NULL,
  PRIMARY KEY (`ArtObjNo`),
  KEY `exhibitionID_idx` (`exhibitionID`),
  KEY `fk_ArtObject_Artist1_idx` (`Artist_ArtistName`,`Artist_DateOfBirth`,`Artist_DateOfDeath`),
  KEY `fk_ArtObject_Museum1_idx` (`Museum_museumID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `artobject`
--

INSERT INTO `artobject` (`ArtObjNo`, `YearOfCreation`, `Title`, `Description`, `Culture`, `Epoch`, `Style`, `exhibitionID`, `Artist_ArtistName`, `Artist_DateOfBirth`, `Artist_DateOfDeath`, `Museum_museumID`) VALUES
(4, '1476-02-21 00:00:00', 'MonaLisa', 'Girl with smile', 'Italy', 'Rainessance', 'Abstract', 3, 'Leonardo Davinci', '1954-12-01 00:00:00', '2014-01-10 00:00:00', 1),
(6, '1954-12-01 00:00:00', 'Pink Lady', 'Hood with Woman', 'kazakhstan', 'Modern', 'Abstract', 1, 'John', '1943-06-03 00:00:00', '2001-01-04 00:00:00', 1),
(10, '1956-12-01 00:00:00', 'David', 'Sculpture old and beautiful', 'Italian ', 'Rainessance', 'Abstract', 2, 'Michelangelo', '1921-02-05 00:00:00', '1994-03-04 00:00:00', 1),
(11, '1444-01-11 00:00:00', 'The last Supper', 'About Jesus', 'Italian', 'Rainessance', 'Classic', 3, 'Leonardo Davinci', '1954-12-01 00:00:00', '2014-01-10 00:00:00', 1),
(13, '1300-01-11 00:00:00', 'Sunrise', 'Beautiful Sun', 'Russian', 'Modern', 'Abstract', 2, 'Ivan Ivanov', '1933-12-01 00:00:00', '2017-01-10 00:00:00', 1),
(14, '1550-01-11 00:00:00', 'Vitruvian Man', 'Human Body in Circle', 'Italy', 'Rainessance', 'Classic', 3, 'Leonardo Davinci', '1954-12-01 00:00:00', '2014-01-10 00:00:00', 1),
(15, '1930-09-01 00:00:00', 'Death of Dragon', 'psychedelic art ', 'China', 'Modern', 'psychedelic installation', 4, 'Sin Zing', '1889-09-04 00:00:00', '1934-09-06 00:00:00', 1),
(16, '1929-10-13 00:00:00', 'Rise of the Dragon', 'psychedelic installation', 'China', 'Modern', 'psychedelic art', 3, 'Sin Zing', '1889-09-04 00:00:00', '1934-09-06 00:00:00', 1),
(17, '1933-10-13 00:00:00', 'Dragon statue', 'statue of mighty dragon', 'China', 'modern', 'statue', 2, 'Sin Zing', '1889-09-04 00:00:00', '1934-09-06 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `artsfriendscircle`
--

CREATE TABLE IF NOT EXISTS `artsfriendscircle` (
  `memberID` int(11) NOT NULL AUTO_INCREMENT,
  `memberName` varchar(45) DEFAULT NULL,
  `member_description` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `contactName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`memberID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `artsfriendscircle`
--

INSERT INTO `artsfriendscircle` (`memberID`, `memberName`, `member_description`, `address`, `phone`, `contactName`) VALUES
(1, 'Museum Ivan', 'One the worst museum in Moscow', 'Moscow', 12323423, 'IvanIvan'),
(2, 'Museum Aberdeen', 'Aberdeen Museum of History', 'Linksfieldgarden AS125PK', 932109523, 'John Paul'),
(4, 'Museum Kanat', 'Imaginary Museum', 'Neverland', 708, 'Kanat');

-- --------------------------------------------------------

--
-- Table structure for table `borrowed`
--

CREATE TABLE IF NOT EXISTS `borrowed` (
  `DateBorrowed` datetime DEFAULT NULL,
  `DateOfReturn` datetime DEFAULT NULL,
  `ArtsFriendsCircle_memberID` int(11) NOT NULL,
  `ArtObject_ArtObjNo` int(11) NOT NULL,
  PRIMARY KEY (`ArtObject_ArtObjNo`),
  KEY `fk_Borrowed_ArtsFriendsCircle1_idx` (`ArtsFriendsCircle_memberID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `borrowed`
--

INSERT INTO `borrowed` (`DateBorrowed`, `DateOfReturn`, `ArtsFriendsCircle_memberID`, `ArtObject_ArtObjNo`) VALUES
('1940-02-03 00:00:00', '2009-09-01 00:00:00', 2, 4),
('1941-09-01 00:00:00', '2001-09-01 00:00:00', 2, 11),
('2010-07-09 01:00:00', '2017-10-09 00:00:00', 4, 13);

-- --------------------------------------------------------

--
-- Stand-in structure for view `change_the_date_of_featured_ex`
--
CREATE TABLE IF NOT EXISTS `change_the_date_of_featured_ex` (
`StartDate` datetime
,`endDate` datetime
,`Exhibitions_ExhibitionID` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `count_artobj_regex_sort`
--
CREATE TABLE IF NOT EXISTS `count_artobj_regex_sort` (
`Amount` bigint(21)
,`Art_Object_Type` varchar(18)
,`Regular_Exhibiton_ID` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `currator`
--

CREATE TABLE IF NOT EXISTS `currator` (
  `Staff_StaffIDNo` int(11) NOT NULL,
  PRIMARY KEY (`Staff_StaffIDNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `currator`
--

INSERT INTO `currator` (`Staff_StaffIDNo`) VALUES
(2),
(4),
(5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `currator_for_given_artobj`
--
CREATE TABLE IF NOT EXISTS `currator_for_given_artobj` (
`fname` varchar(45)
,`lname` varchar(45)
,`Title` varchar(45)
,`Artist_ArtistName` varchar(45)
);
-- --------------------------------------------------------

--
-- Table structure for table `curratorobject`
--

CREATE TABLE IF NOT EXISTS `curratorobject` (
  `Currator_Staff_StaffIDNo` int(11) NOT NULL,
  `ArtObject_ArtObjNo` int(11) NOT NULL,
  `CurratorObject` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`CurratorObject`),
  KEY `fk_CurratorObject_Currator1_idx` (`Currator_Staff_StaffIDNo`),
  KEY `fk_CurratorObject_ArtObject1_idx` (`ArtObject_ArtObjNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `curratorobject`
--

INSERT INTO `curratorobject` (`Currator_Staff_StaffIDNo`, `ArtObject_ArtObjNo`, `CurratorObject`) VALUES
(2, 4, 1),
(4, 4, 2),
(2, 10, 3),
(2, 11, 4),
(4, 11, 5);

-- --------------------------------------------------------

--
-- Table structure for table `exhibitions`
--

CREATE TABLE IF NOT EXISTS `exhibitions` (
  `ExhibitionID` int(11) NOT NULL,
  `Museum_museumID` int(11) NOT NULL,
  PRIMARY KEY (`ExhibitionID`),
  KEY `fk_Exhibitions_Museum1_idx` (`Museum_museumID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exhibitions`
--

INSERT INTO `exhibitions` (`ExhibitionID`, `Museum_museumID`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `featured_exhibitions`
--

CREATE TABLE IF NOT EXISTS `featured_exhibitions` (
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `Exhibitions_ExhibitionID` int(11) NOT NULL,
  `feature` varchar(45) NOT NULL,
  PRIMARY KEY (`Exhibitions_ExhibitionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `featured_exhibitions`
--

INSERT INTO `featured_exhibitions` (`startDate`, `endDate`, `Exhibitions_ExhibitionID`, `feature`) VALUES
('2017-11-11 00:00:00', '2017-12-01 00:00:00', 1, 'Modern'),
('2014-11-11 00:00:00', '2015-11-11 00:00:00', 3, 'Leonardo Davinci'),
('2017-10-01 00:00:00', '2017-11-01 00:00:00', 4, 'Russian culture');

-- --------------------------------------------------------

--
-- Table structure for table `gallerysupervisor`
--

CREATE TABLE IF NOT EXISTS `gallerysupervisor` (
  `Staff_StaffIDNo` int(11) NOT NULL,
  `Exhibitions_ExhibitionID` int(11) NOT NULL,
  PRIMARY KEY (`Staff_StaffIDNo`),
  KEY `fk_GallerySupervisor_Exhibitions1_idx` (`Exhibitions_ExhibitionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gallerysupervisor`
--

INSERT INTO `gallerysupervisor` (`Staff_StaffIDNo`, `Exhibitions_ExhibitionID`) VALUES
(6, 1),
(1, 3),
(3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

CREATE TABLE IF NOT EXISTS `invitations` (
  `InvitationsID` int(11) NOT NULL,
  `Museum_museumID` int(11) NOT NULL,
  `Loyalcustomer_LoyaltyNo` int(11) NOT NULL,
  PRIMARY KEY (`InvitationsID`),
  KEY `fk_Invitations_Museum1_idx` (`Museum_museumID`),
  KEY `fk_Invitations_Loyalcustomer1_idx` (`Loyalcustomer_LoyaltyNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invitations`
--

INSERT INTO `invitations` (`InvitationsID`, `Museum_museumID`, `Loyalcustomer_LoyaltyNo`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_all_art_objects_in_feaex_from_artist123`
--
CREATE TABLE IF NOT EXISTS `list_all_art_objects_in_feaex_from_artist123` (
`Title` varchar(45)
,`Style` varchar(45)
,`Artist_ArtistName` varchar(45)
,`startDate` datetime
,`endDate` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `list_all_featex_start_end_loyalcus`
--
CREATE TABLE IF NOT EXISTS `list_all_featex_start_end_loyalcus` (
`startDate` datetime
,`endDate` datetime
,`Exhibitions_ExhibitionID` int(11)
,`Fname` varchar(45)
,`Lname` varchar(45)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `list_artobj_borrowed_from_museum`
--
CREATE TABLE IF NOT EXISTS `list_artobj_borrowed_from_museum` (
`ArtObjNo` int(11)
,`Title` varchar(45)
,`Description` varchar(45)
,`Artist_ArtistName` varchar(45)
,`DateBorrowed` datetime
,`DateOfReturn` datetime
,`memberName` varchar(45)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `list_supervisor_given_featex`
--
CREATE TABLE IF NOT EXISTS `list_supervisor_given_featex` (
`Artist_ArtistName` varchar(45)
,`Culture` varchar(45)
,`startDate` datetime
,`endDate` datetime
,`fname` varchar(45)
,`lname` varchar(45)
);
-- --------------------------------------------------------

--
-- Table structure for table `loyalcustomer`
--

CREATE TABLE IF NOT EXISTS `loyalcustomer` (
  `LoyaltyNo` int(11) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(45) DEFAULT NULL,
  `Lname` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`LoyaltyNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `loyalcustomer`
--

INSERT INTO `loyalcustomer` (`LoyaltyNo`, `Fname`, `Lname`) VALUES
(1, 'Jack', 'Bean'),
(2, 'Robin', 'Hood'),
(3, 'Vladimir', 'Putin');

-- --------------------------------------------------------

--
-- Table structure for table `mimic_artobjects`
--

CREATE TABLE IF NOT EXISTS `mimic_artobjects` (
  `Price` int(11) DEFAULT NULL,
  `Featured_exhibitions_Exhibitions_ExhibitionID` int(11) NOT NULL,
  KEY `fk_Mimic_ArtObjects_Featured_exhibitions1_idx` (`Featured_exhibitions_Exhibitions_ExhibitionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mimic_artobjects`
--

INSERT INTO `mimic_artobjects` (`Price`, `Featured_exhibitions_Exhibitions_ExhibitionID`) VALUES
(1000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `museum`
--

CREATE TABLE IF NOT EXISTS `museum` (
  `museumID` int(11) NOT NULL AUTO_INCREMENT,
  `ArtsFriendsCircle_memberID` int(11) NOT NULL,
  PRIMARY KEY (`museumID`),
  KEY `fk_Museum_ArtsFriendsCircle1_idx` (`ArtsFriendsCircle_memberID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `museum`
--

INSERT INTO `museum` (`museumID`, `ArtsFriendsCircle_memberID`) VALUES
(1, 1),
(2, 2),
(4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `others`
--

CREATE TABLE IF NOT EXISTS `others` (
  `Type` varchar(45) DEFAULT NULL,
  `ArtObject_ArtObjNo` int(11) NOT NULL,
  PRIMARY KEY (`ArtObject_ArtObjNo`),
  KEY `fk_Others_ArtObject1_idx` (`ArtObject_ArtObjNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `others`
--

INSERT INTO `others` (`Type`, `ArtObject_ArtObjNo`) VALUES
('Installation', 14),
('installation', 15),
('installation', 16);

-- --------------------------------------------------------

--
-- Table structure for table `painting`
--

CREATE TABLE IF NOT EXISTS `painting` (
  `Material` varchar(45) DEFAULT NULL,
  `Types` varchar(45) DEFAULT NULL,
  `ArtObject_ArtObjNo` int(11) NOT NULL,
  PRIMARY KEY (`ArtObject_ArtObjNo`),
  KEY `fk_Painting_ArtObject1_idx` (`ArtObject_ArtObjNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `painting`
--

INSERT INTO `painting` (`Material`, `Types`, `ArtObject_ArtObjNo`) VALUES
('paper', 'oil', 4),
('paper', 'oil', 11),
('paper', 'oil', 13);

-- --------------------------------------------------------

--
-- Table structure for table `permanent`
--

CREATE TABLE IF NOT EXISTS `permanent` (
  `DateOfAcquiry` datetime DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `Cost` int(11) DEFAULT NULL,
  `ArtObject_ArtObjNo` int(11) NOT NULL,
  PRIMARY KEY (`ArtObject_ArtObjNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permanent`
--

INSERT INTO `permanent` (`DateOfAcquiry`, `Status`, `Cost`, `ArtObject_ArtObjNo`) VALUES
('1964-02-11 00:00:00', 'ruh', 10202, 6),
('2011-08-13 00:00:00', 'Bought', 12300000, 16),
('2017-10-01 00:00:00', 'Bought ', 15000, 17);

-- --------------------------------------------------------

--
-- Table structure for table `preferences`
--

CREATE TABLE IF NOT EXISTS `preferences` (
  `PrefencesID` int(11) NOT NULL,
  `Loyalcustomer_LoyaltyNo` int(11) NOT NULL,
  `Featured_exhibitions_Exhibitions_ExhibitionID` int(11) NOT NULL,
  PRIMARY KEY (`PrefencesID`),
  KEY `fk_Preferences_Loyalcustomer1_idx` (`Loyalcustomer_LoyaltyNo`),
  KEY `fk_Preferences_Featured_exhibitions1_idx` (`Featured_exhibitions_Exhibitions_ExhibitionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `preferences`
--

INSERT INTO `preferences` (`PrefencesID`, `Loyalcustomer_LoyaltyNo`, `Featured_exhibitions_Exhibitions_ExhibitionID`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `regular_exhibitions`
--

CREATE TABLE IF NOT EXISTS `regular_exhibitions` (
  `Exhibitions_ExhibitionID` int(11) NOT NULL,
  PRIMARY KEY (`Exhibitions_ExhibitionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `regular_exhibitions`
--

INSERT INTO `regular_exhibitions` (`Exhibitions_ExhibitionID`) VALUES
(2),
(5),
(6);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `StaffIDNo` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `Museum_museumID` int(11) NOT NULL,
  PRIMARY KEY (`StaffIDNo`),
  KEY `fk_Staff_Museum1_idx` (`Museum_museumID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffIDNo`, `type`, `fname`, `lname`, `Museum_museumID`) VALUES
(1, 'gallery supervisor', 'Ivan', 'Petkov', 1),
(2, 'currator', 'Konstantin', 'Velikov', 1),
(3, 'gallery supervisor', 'Paul', 'John', 1),
(4, 'currator', 'Peter', 'Dolandson', 1),
(5, 'Currator', 'Abu-Hasib', 'IbnHattab', 1),
(6, 'gallery supervisor', 'Alexey', 'Milnchenko', 1);

-- --------------------------------------------------------

--
-- Table structure for table `statuesculpture`
--

CREATE TABLE IF NOT EXISTS `statuesculpture` (
  `Weight` int(11) DEFAULT NULL,
  `Height` int(11) DEFAULT NULL,
  `Material` varchar(45) DEFAULT NULL,
  `ArtObject_ArtObjNo` int(11) NOT NULL,
  PRIMARY KEY (`ArtObject_ArtObjNo`),
  KEY `fk_StatueSculpture_ArtObject1_idx` (`ArtObject_ArtObjNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statuesculpture`
--

INSERT INTO `statuesculpture` (`Weight`, `Height`, `Material`, `ArtObject_ArtObjNo`) VALUES
(100, 2, 'stone', 6),
(50, 2, 'marble', 10),
(135, 128, 'Stone', 17);

-- --------------------------------------------------------

--
-- Structure for view `Art_object`
--
DROP TABLE IF EXISTS `Art_object`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `Art_object` AS select `artobject`.`YearOfCreation` AS `YearOfCreation`,`artobject`.`Title` AS `Title`,`artobject`.`Description` AS `Description`,`artobject`.`Culture` AS `Culture`,`artobject`.`Epoch` AS `Epoch`,`artobject`.`Style` AS `Style`,`artobject`.`Artist_ArtistName` AS `Artist_ArtistName`,`permanent`.`DateOfAcquiry` AS `DateOfAcquiry`,`permanent`.`Status` AS `Status`,`permanent`.`Cost` AS `Cost`,`permanent`.`ArtObject_ArtObjNo` AS `ArtObject_ArtObjNo` from (`artobject` join `permanent`) where ((`permanent`.`ArtObject_ArtObjNo` = '6') and (`artobject`.`ArtObjNo` = '6'));

-- --------------------------------------------------------

--
-- Structure for view `Count_objects_from_artist`
--
DROP TABLE IF EXISTS `Count_objects_from_artist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `Count_objects_from_artist` AS select count(`artobject`.`ArtObjNo`) AS `Count_of_Objects`,`artobject`.`Artist_ArtistName` AS `Artist_name` from `artobject` where (`artobject`.`Artist_ArtistName` = 'Leonardo Davinci');

-- --------------------------------------------------------

--
-- Structure for view `Select_from_borrowed_a`
--
DROP TABLE IF EXISTS `Select_from_borrowed_a`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `Select_from_borrowed_a` AS select `borrowed`.`DateBorrowed` AS `DateBorrowed`,`borrowed`.`DateOfReturn` AS `DateOfReturn`,`artobject`.`YearOfCreation` AS `YearOfCreation`,`artobject`.`Title` AS `Title`,`artobject`.`Culture` AS `Culture`,`artobject`.`Epoch` AS `Epoch`,`artobject`.`Style` AS `Style`,`artobject`.`Artist_ArtistName` AS `Artist_ArtistName`,`artsfriendscircle`.`memberName` AS `memberName` from ((`artsfriendscircle` join `borrowed`) join `artobject`) where (`artsfriendscircle`.`memberID` <> '1') group by `artobject`.`Artist_ArtistName`;

-- --------------------------------------------------------

--
-- Structure for view `change_the_date_of_featured_ex`
--
DROP TABLE IF EXISTS `change_the_date_of_featured_ex`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `change_the_date_of_featured_ex` AS select `featured_exhibitions`.`startDate` AS `StartDate`,`featured_exhibitions`.`endDate` AS `endDate`,`featured_exhibitions`.`Exhibitions_ExhibitionID` AS `Exhibitions_ExhibitionID` from `featured_exhibitions` where (`featured_exhibitions`.`Exhibitions_ExhibitionID` = '1');

-- --------------------------------------------------------

--
-- Structure for view `count_artobj_regex_sort`
--
DROP TABLE IF EXISTS `count_artobj_regex_sort`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `count_artobj_regex_sort` AS select count(`painting`.`ArtObject_ArtObjNo`) AS `Amount`,'paintings' AS `Art_Object_Type`,`regular_exhibitions`.`Exhibitions_ExhibitionID` AS `Regular_Exhibiton_ID` from (`painting` join `regular_exhibitions`) where `painting`.`ArtObject_ArtObjNo` in (select `artobject`.`ArtObjNo` from (`artobject` join `regular_exhibitions`) where (`artobject`.`exhibitionID` = `regular_exhibitions`.`Exhibitions_ExhibitionID`)) union select count(`statuesculpture`.`ArtObject_ArtObjNo`) AS `Amount`,'statues/sculptures' AS `Art_Object_Type`,`regular_exhibitions`.`Exhibitions_ExhibitionID` AS `Regular_Exhibiton_ID` from (`statuesculpture` join `regular_exhibitions`) where `statuesculpture`.`ArtObject_ArtObjNo` in (select `artobject`.`ArtObjNo` from (`artobject` join `regular_exhibitions`) where (`artobject`.`exhibitionID` = `regular_exhibitions`.`Exhibitions_ExhibitionID`)) union select count(`others`.`ArtObject_ArtObjNo`) AS `Amount`,'others' AS `Art_Object_Type`,`regular_exhibitions`.`Exhibitions_ExhibitionID` AS `Regular_Exhibiton_ID` from (`others` join `regular_exhibitions`) where `others`.`ArtObject_ArtObjNo` in (select `artobject`.`ArtObjNo` from (`artobject` join `regular_exhibitions`) where (`artobject`.`exhibitionID` = `regular_exhibitions`.`Exhibitions_ExhibitionID`)) order by `Amount` desc;

-- --------------------------------------------------------

--
-- Structure for view `currator_for_given_artobj`
--
DROP TABLE IF EXISTS `currator_for_given_artobj`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `currator_for_given_artobj` AS select `staff`.`fname` AS `fname`,`staff`.`lname` AS `lname`,`artobject`.`Title` AS `Title`,`artobject`.`Artist_ArtistName` AS `Artist_ArtistName` from (`artobject` join `staff`) where `staff`.`StaffIDNo` in (select `currator`.`Staff_StaffIDNo` from (`currator` join `artobject`) where (`artobject`.`Title` = 'MonaLisa')) group by `staff`.`StaffIDNo`;

-- --------------------------------------------------------

--
-- Structure for view `list_all_art_objects_in_feaex_from_artist123`
--
DROP TABLE IF EXISTS `list_all_art_objects_in_feaex_from_artist123`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `list_all_art_objects_in_feaex_from_artist123` AS select `artobject`.`Title` AS `Title`,`artobject`.`Style` AS `Style`,`artobject`.`Artist_ArtistName` AS `Artist_ArtistName`,`featured_exhibitions`.`startDate` AS `startDate`,`featured_exhibitions`.`endDate` AS `endDate` from (`artobject` join `featured_exhibitions`) where `artobject`.`ArtObjNo` in (select `artobject`.`ArtObjNo` from (`artobject` join `featured_exhibitions`) where ((`artobject`.`exhibitionID` = `featured_exhibitions`.`Exhibitions_ExhibitionID`) and (`artobject`.`Artist_ArtistName` = 'Leonardo Davinci'))) group by `artobject`.`Title`;

-- --------------------------------------------------------

--
-- Structure for view `list_all_featex_start_end_loyalcus`
--
DROP TABLE IF EXISTS `list_all_featex_start_end_loyalcus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `list_all_featex_start_end_loyalcus` AS select `featured_exhibitions`.`startDate` AS `startDate`,`featured_exhibitions`.`endDate` AS `endDate`,`featured_exhibitions`.`Exhibitions_ExhibitionID` AS `Exhibitions_ExhibitionID`,`loyalcustomer`.`Fname` AS `Fname`,`loyalcustomer`.`Lname` AS `Lname` from (`featured_exhibitions` join `loyalcustomer`) where `loyalcustomer`.`LoyaltyNo` in (select `preferences`.`Loyalcustomer_LoyaltyNo` from (`loyalcustomer` join `preferences`) where (`preferences`.`Featured_exhibitions_Exhibitions_ExhibitionID` = `featured_exhibitions`.`Exhibitions_ExhibitionID`));

-- --------------------------------------------------------

--
-- Structure for view `list_artobj_borrowed_from_museum`
--
DROP TABLE IF EXISTS `list_artobj_borrowed_from_museum`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `list_artobj_borrowed_from_museum` AS select `artobject`.`ArtObjNo` AS `ArtObjNo`,`artobject`.`Title` AS `Title`,`artobject`.`Description` AS `Description`,`artobject`.`Artist_ArtistName` AS `Artist_ArtistName`,`borrowed`.`DateBorrowed` AS `DateBorrowed`,`borrowed`.`DateOfReturn` AS `DateOfReturn`,`artsfriendscircle`.`memberName` AS `memberName` from ((`artobject` join `borrowed`) join `artsfriendscircle`) where (`artobject`.`ArtObjNo` in (select `borrowed`.`ArtObject_ArtObjNo` from `borrowed` where (`borrowed`.`ArtsFriendsCircle_memberID` <> 0)) and (`artsfriendscircle`.`memberID` = `borrowed`.`ArtsFriendsCircle_memberID`)) group by `artobject`.`ArtObjNo`;

-- --------------------------------------------------------

--
-- Structure for view `list_supervisor_given_featex`
--
DROP TABLE IF EXISTS `list_supervisor_given_featex`;

CREATE ALGORITHM=UNDEFINED DEFINER=`t01kkk16_museum`@`%.abdn.ac.uk` SQL SECURITY DEFINER VIEW `list_supervisor_given_featex` AS select `artobject`.`Artist_ArtistName` AS `Artist_ArtistName`,`artobject`.`Culture` AS `Culture`,`featured_exhibitions`.`startDate` AS `startDate`,`featured_exhibitions`.`endDate` AS `endDate`,`staff`.`fname` AS `fname`,`staff`.`lname` AS `lname` from ((`artobject` join `staff`) join `featured_exhibitions`) where (`artobject`.`ArtObjNo` in (select `artobject`.`ArtObjNo` from (`artobject` join `gallerysupervisor`) where (`artobject`.`exhibitionID` = `gallerysupervisor`.`Exhibitions_ExhibitionID`)) and `staff`.`StaffIDNo` in (select `gallerysupervisor`.`Staff_StaffIDNo` from (`gallerysupervisor` join `featured_exhibitions`) where (`featured_exhibitions`.`feature` = 'Leonardo Davinci'))) group by `staff`.`StaffIDNo`;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artobject`
--
ALTER TABLE `artobject`
  ADD CONSTRAINT `exhibitionID` FOREIGN KEY (`exhibitionID`) REFERENCES `exhibitions` (`ExhibitionID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ArtObject_Artist1` FOREIGN KEY (`Artist_ArtistName`, `Artist_DateOfBirth`, `Artist_DateOfDeath`) REFERENCES `artist` (`ArtistName`, `DateOfBirth`, `DateOfDeath`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ArtObject_Museum1` FOREIGN KEY (`Museum_museumID`) REFERENCES `museum` (`museumID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `borrowed`
--
ALTER TABLE `borrowed`
  ADD CONSTRAINT `fk_Borrowed_ArtObject1` FOREIGN KEY (`ArtObject_ArtObjNo`) REFERENCES `artobject` (`ArtObjNo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Borrowed_ArtsFriendsCircle1` FOREIGN KEY (`ArtsFriendsCircle_memberID`) REFERENCES `artsfriendscircle` (`memberID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `currator`
--
ALTER TABLE `currator`
  ADD CONSTRAINT `fk_Currator_Staff1` FOREIGN KEY (`Staff_StaffIDNo`) REFERENCES `staff` (`StaffIDNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `curratorobject`
--
ALTER TABLE `curratorobject`
  ADD CONSTRAINT `fk_CurratorObject_ArtObject1` FOREIGN KEY (`ArtObject_ArtObjNo`) REFERENCES `artobject` (`ArtObjNo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_CurratorObject_Currator1` FOREIGN KEY (`Currator_Staff_StaffIDNo`) REFERENCES `currator` (`Staff_StaffIDNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `exhibitions`
--
ALTER TABLE `exhibitions`
  ADD CONSTRAINT `fk_Exhibitions_Museum1` FOREIGN KEY (`Museum_museumID`) REFERENCES `museum` (`museumID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `featured_exhibitions`
--
ALTER TABLE `featured_exhibitions`
  ADD CONSTRAINT `fk_Featured_exhibitions_Exhibitions1` FOREIGN KEY (`Exhibitions_ExhibitionID`) REFERENCES `exhibitions` (`ExhibitionID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `gallerysupervisor`
--
ALTER TABLE `gallerysupervisor`
  ADD CONSTRAINT `fk_GallerySupervisor_Exhibitions1` FOREIGN KEY (`Exhibitions_ExhibitionID`) REFERENCES `exhibitions` (`ExhibitionID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_GallerySupervisor_Staff1` FOREIGN KEY (`Staff_StaffIDNo`) REFERENCES `staff` (`StaffIDNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `invitations`
--
ALTER TABLE `invitations`
  ADD CONSTRAINT `fk_Invitations_Loyalcustomer1` FOREIGN KEY (`Loyalcustomer_LoyaltyNo`) REFERENCES `loyalcustomer` (`LoyaltyNo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Invitations_Museum1` FOREIGN KEY (`Museum_museumID`) REFERENCES `museum` (`museumID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `mimic_artobjects`
--
ALTER TABLE `mimic_artobjects`
  ADD CONSTRAINT `fk_Mimic_ArtObjects_Featured_exhibitions1` FOREIGN KEY (`Featured_exhibitions_Exhibitions_ExhibitionID`) REFERENCES `featured_exhibitions` (`Exhibitions_ExhibitionID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `museum`
--
ALTER TABLE `museum`
  ADD CONSTRAINT `fk_Museum_ArtsFriendsCircle1` FOREIGN KEY (`ArtsFriendsCircle_memberID`) REFERENCES `artsfriendscircle` (`memberID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `others`
--
ALTER TABLE `others`
  ADD CONSTRAINT `fk_Others_ArtObject1` FOREIGN KEY (`ArtObject_ArtObjNo`) REFERENCES `artobject` (`ArtObjNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `painting`
--
ALTER TABLE `painting`
  ADD CONSTRAINT `fk_Painting_ArtObject1` FOREIGN KEY (`ArtObject_ArtObjNo`) REFERENCES `artobject` (`ArtObjNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `permanent`
--
ALTER TABLE `permanent`
  ADD CONSTRAINT `fk_Permanent_ArtObject1` FOREIGN KEY (`ArtObject_ArtObjNo`) REFERENCES `artobject` (`ArtObjNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `preferences`
--
ALTER TABLE `preferences`
  ADD CONSTRAINT `fk_Preferences_Featured_exhibitions1` FOREIGN KEY (`Featured_exhibitions_Exhibitions_ExhibitionID`) REFERENCES `featured_exhibitions` (`Exhibitions_ExhibitionID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Preferences_Loyalcustomer1` FOREIGN KEY (`Loyalcustomer_LoyaltyNo`) REFERENCES `loyalcustomer` (`LoyaltyNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `regular_exhibitions`
--
ALTER TABLE `regular_exhibitions`
  ADD CONSTRAINT `fk_Regular_exhibitions_Exhibitions1` FOREIGN KEY (`Exhibitions_ExhibitionID`) REFERENCES `exhibitions` (`ExhibitionID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `fk_Staff_Museum1` FOREIGN KEY (`Museum_museumID`) REFERENCES `museum` (`museumID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `statuesculpture`
--
ALTER TABLE `statuesculpture`
  ADD CONSTRAINT `fk_StatueSculpture_ArtObject1` FOREIGN KEY (`ArtObject_ArtObjNo`) REFERENCES `artobject` (`ArtObjNo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
